package com.practice;

public class Employee 
{
	private String firstName;
	private String lastName;
	private String Course;
	
	public String getCourse() 
	{
		return Course;
	}

	public void setCourse(String course) 
	{
		Course = course;
	}

	public Employee(String firstName, String lastName, String course) 
	{
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.Course = course;
	}
	
	public String getFirstName() 
	{
		return firstName;
	}
	public void setFirstName(String firstName) 
	{
		this.firstName = firstName;
	}
	public String getLastName() 
	{
		return lastName;
	}
	public void setLastName(String lastName) 
	{
		this.lastName = lastName;
	}
}
