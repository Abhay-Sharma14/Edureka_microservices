package com.practice.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.practice.Employee;

@RestController
public class Controller 
{	
	
	// http://localhost:8080/student
	@GetMapping("/employee")
	public Employee getEmployee() 
	{
		return new Employee("Nameet", "Mankar", "Microservices");
	}
}