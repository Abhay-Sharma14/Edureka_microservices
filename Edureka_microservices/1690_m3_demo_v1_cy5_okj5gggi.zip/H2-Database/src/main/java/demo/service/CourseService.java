package demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import demo.model.Course;
import demo.repository.CourseRepository;

@Service
public class CourseService 
{
	@Autowired
	CourseRepository courseRepository;
	
	public List<Course> getAllCourse() 
	{
		List<Course> courses = new ArrayList<Course>();
		courseRepository.findAll().forEach(course -> courses.add(course));
		return courses;
	}
	
	public Course getCourseById(int id) 
	{
		return courseRepository.findById(id).get();
	}
	
	public void saveOrUpdate(Course course) 
	{
		courseRepository.save(course);
	}

	public void delete(int id) 
	{
		courseRepository.deleteById(id);
	}
	
	
}
