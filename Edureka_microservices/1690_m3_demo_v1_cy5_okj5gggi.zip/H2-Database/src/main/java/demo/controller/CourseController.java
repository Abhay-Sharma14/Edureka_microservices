package demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import demo.model.Course;
import demo.service.CourseService;

@RestController
public class CourseController 
{
	@Autowired
	CourseService courseService;
	
	@GetMapping("/course")
	private List<Course> getAllCourse() 
	{
		return courseService.getAllCourse();
	}
	
	@GetMapping("/course/{id}")
	private Course getCourse(@PathVariable("id") int id) 
	{
		return courseService.getCourseById(id);
	}
	
	@DeleteMapping("/course/{id}")
	private void deleteCourse(@PathVariable("id") int id) 
	{
		courseService.delete(id);
	}
	
	@PostMapping("/course")
	private int saveCourse(@RequestBody Course course) 
	{
		courseService.saveOrUpdate(course);
		return course.getId();
	}
}
