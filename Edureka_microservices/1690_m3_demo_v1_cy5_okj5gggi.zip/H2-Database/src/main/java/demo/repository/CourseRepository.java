package demo.repository;

import org.springframework.data.repository.CrudRepository;

import demo.model.Course;

public interface CourseRepository extends CrudRepository<Course, Integer>
{

}
