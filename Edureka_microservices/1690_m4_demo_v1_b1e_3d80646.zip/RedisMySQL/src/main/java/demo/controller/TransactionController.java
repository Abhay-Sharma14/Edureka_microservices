package demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import demo.model.Transaction;
import demo.repository.TransactionRepository;
import demo.*;

@RestController
@RequestMapping("/api")
public class TransactionController 
{
    @Autowired
    private TransactionRepository transactionRepository;

    @PostMapping("/transactions")
    public Transaction addTransaction(@RequestBody Transaction transaction) 
    {
        return transactionRepository.save(transaction);
    }

    @GetMapping("transactions/{transactionId}")
    @Cacheable(value = "transactions",key = "#transactionId")
    public Transaction findTransactionById(@PathVariable(value = "transactionId") Integer transactionId) 
    {
        System.out.println("Transactions fetching from database:: "+transactionId);
        return transactionRepository.findById(transactionId).orElseThrow(
                () -> new ResouceNotFoundException("Transaction not found" + transactionId));
    }


    @PutMapping("transactions/{transactionId}")
    @CachePut(value = "transactions",key = "#transactionId")
    public Transaction updateTransaction(@PathVariable(value = "transactionId") Integer transactionId, @RequestBody Transaction transactionDetails) 
    {
        Transaction transaction = transactionRepository.findById(transactionId)
                .orElseThrow(() -> new ResouceNotFoundException("Transaction not found for this id : " + transactionId));
        
        transaction.setSender_name(transactionDetails.getSender_name());
        transaction.setReceiver_name(transactionDetails.getReceiver_name());
        transaction.setAmt(transactionDetails.getAmt());
        
        final Transaction updatedTransaction = transactionRepository.save(transaction);
        return updatedTransaction;
    }
    
    @DeleteMapping("transactions/{id}")
    @CacheEvict(value = "transactions", allEntries = true)
    public void deleteTransaction(@PathVariable(value = "id") Integer transactionId) 
    {
        Transaction transaction = transactionRepository.findById(transactionId).orElseThrow(
                () -> new ResouceNotFoundException("Employee not found" + transactionId));
        transactionRepository.delete(transaction);
    }
}
