package demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

import org.springframework.cache.annotation.Cacheable;

@SpringBootApplication
@EnableCaching
@EnableSwagger2
public class RedisMySqlApplication {
	@Cacheable
	public static void main(String[] args) {
		SpringApplication.run(RedisMySqlApplication.class, args);

	}

}
