package com.springbootmicrometer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootMicrometerApplicationTests {

	@Test
	void contextLoads() {
	}

}
